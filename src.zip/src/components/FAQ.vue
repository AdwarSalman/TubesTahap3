<template>
  <!-- BAGIAN 5 FAQ -->
  <section class="faq-section">
    <h2>Frequently Asked Questions</h2>

    <details class="faq-item">
      <summary>What are the requirements to adopt a cat?</summary>
      <p>You need to fill out the adoption form, provide ID, and agree to the adoption policy.</p>
    </details>

    <details class="faq-item">
      <summary>What documents or information need to be prepared for adoption?</summary>
      <p>Prepare your ID card, proof of residence, and any references if required.</p>
    </details>

    <details class="faq-item">
      <summary>Is there a fee to adopt a cat?</summary>
      <p>Some shelters may ask for a small adoption fee to cover medical costs.</p>
    </details>

    <details class="faq-item">
      <summary>Do you have any questions?</summary>
      <p>You can contact us anytime via email or our social media accounts.</p>
    </details>
  </section>
</template>

<style scoped>
/*===========
  BAGIAN 5 FAQ
  ===========*/
.faq-section {
  background-color: oklch(96.7% 0.003 264.542);
  padding: 40px 10px;
  width: 100%;
  margin: 0;
}

.faq-section h2 {
  background-color: oklch(76.9% 0.188 70.08);
  display: inline-block;
  padding: 10px 20px;
  border-radius: 15px;
}

.faq-title {
  background-color: #EBE7DF;
  display: inline-block;
  padding: 11px 6px;
  border-radius: 5px;
  margin-bottom: 20px;
  font-weight: bold;
}

.faq-item {
  background-color: oklch(92.3% 0.003 48.717);
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 10px;
  margin-bottom: 20px;
  box-shadow: 4px 4px 4px rgba(0,0,0,0.3);
  max-width: 1400px;
}
</style>

<script setup>

</script>
