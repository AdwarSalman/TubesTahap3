<template>
    <Dashboard/>
</template>

<script setup>
import Dashboard from '@/components/Dashboard.vue';
</script>